# Repte0

Repositorio del proyecto Repte0.

## Ejercicio de captura de errores

La carpeta `CodiError` contiene el ejemplo `Error.html` para demostrar:

- Un error provocado intencionadamente desde el código JavaScript.
- Un error provocado al seleccionar una opción no válida.

En ambos casos se captura el error con `try...catch` y se informa al usuario en la consola y en la página.

Consulta `CodiError/README.md` para probarlo y guardar las capturas solicitadas.
